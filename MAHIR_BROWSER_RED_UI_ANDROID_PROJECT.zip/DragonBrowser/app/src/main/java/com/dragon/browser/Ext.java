package com.dragon.browser;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.webkit.MimeTypeMap;
import android.webkit.WebResourceResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Extension manager: unzip, list, storage, content-script registry, file serving. */
final class Ext {

    static final String PREFIX = "/__dm_ext__/";

    static final class Info {
        String id;
        String name;
        String version;
        File dir;
        boolean enabled;
        JSONObject manifest;

        String popupPath() {
            String[] keys = {"action", "browser_action", "page_action"};
            for (String k : keys) {
                JSONObject o = manifest.optJSONObject(k);
                if (o != null) {
                    String p = o.optString("default_popup", "");
                    if (p.length() > 0) return stripSlash(p);
                }
            }
            return null;
        }

        boolean hasBackground() {
            JSONObject bg = manifest.optJSONObject("background");
            if (bg == null) return false;
            return bg.optJSONArray("scripts") != null
                    || bg.optString("page", "").length() > 0
                    || bg.optString("service_worker", "").length() > 0;
        }
    }

    private final Context ctx;
    private final File root;
    private final SharedPreferences prefs;
    private final Map<String, JSONObject> stores = new HashMap<>();
    private List<Info> cache;
    private String shimJs;

    Ext(Context c) {
        ctx = c.getApplicationContext();
        root = new File(ctx.getFilesDir(), "ext");
        //noinspection ResultOfMethodCallIgnored
        root.mkdirs();
        prefs = ctx.getSharedPreferences("ext", Context.MODE_PRIVATE);
    }

    static String stripSlash(String s) {
        while (s.startsWith("/")) s = s.substring(1);
        return s;
    }

    // ------------------------------------------------------------------ list / state

    synchronized List<Info> list() {
        if (cache != null) return cache;
        List<Info> out = new ArrayList<>();
        File[] dirs = root.listFiles();
        if (dirs != null) {
            for (File d : dirs) {
                if (!d.isDirectory() || d.getName().startsWith(".")) continue;
                File mf = new File(d, "manifest.json");
                if (!mf.exists()) continue;
                try {
                    JSONObject m = new JSONObject(readManifestText(mf));
                    Info i = new Info();
                    i.id = d.getName();
                    i.dir = d;
                    i.manifest = m;
                    i.name = resolveMsg(d, m, m.optString("name", i.id));
                    i.version = m.optString("version", "");
                    i.enabled = prefs.getBoolean("en_" + i.id, true);
                    out.add(i);
                } catch (Exception ignored) {
                }
            }
        }
        cache = out;
        return out;
    }

    synchronized Info find(String id) {
        for (Info i : list()) if (i.id.equals(id)) return i;
        return null;
    }

    synchronized void setEnabled(String id, boolean on) {
        prefs.edit().putBoolean("en_" + id, on).apply();
        cache = null;
    }

    synchronized void delete(String id) {
        Info i = find(id);
        if (i != null) deleteRec(i.dir);
        //noinspection ResultOfMethodCallIgnored
        new File(root, ".store_" + id + ".json").delete();
        stores.remove(id);
        prefs.edit().remove("en_" + id).apply();
        cache = null;
    }

    // ------------------------------------------------------------------ install

    synchronized Info install(InputStream in) throws Exception {
        File tmp = new File(root, ".tmp_" + System.nanoTime());
        if (!tmp.mkdirs()) throw new IOException("temp folder");
        try {
            String tmpCanon = tmp.getCanonicalPath() + File.separator;
            long total = 0;
            ZipInputStream zin = new ZipInputStream(in);
            ZipEntry e;
            byte[] buf = new byte[16384];
            while ((e = zin.getNextEntry()) != null) {
                String name = e.getName().replace('\\', '/');
                File out = new File(tmp, name);
                String canon = out.getCanonicalPath();
                if (!(canon + File.separator).startsWith(tmpCanon)) continue; // zip-slip guard
                if (e.isDirectory()) {
                    //noinspection ResultOfMethodCallIgnored
                    out.mkdirs();
                    continue;
                }
                File parent = out.getParentFile();
                if (parent != null) //noinspection ResultOfMethodCallIgnored
                    parent.mkdirs();
                FileOutputStream fo = new FileOutputStream(out);
                try {
                    int n;
                    while ((n = zin.read(buf)) > 0) {
                        total += n;
                        if (total > 150L * 1024 * 1024) throw new IOException("zip too big");
                        fo.write(buf, 0, n);
                    }
                } finally {
                    fo.close();
                }
            }
            File base = findManifestDir(tmp, 0);
            if (base == null) throw new IOException("manifest.json পাওয়া যায়নি");
            JSONObject m = new JSONObject(readManifestText(new File(base, "manifest.json")));
            String name = resolveMsg(base, m, m.optString("name", "extension"));
            String id = "x" + Integer.toHexString(name.hashCode()).replace('-', 'n');
            File target = new File(root, id);
            deleteRec(target);
            if (!base.renameTo(target)) {
                copyRec(base, target);
            }
            cache = null;
            return find(id);
        } finally {
            deleteRec(tmp);
        }
    }

    private File findManifestDir(File d, int depth) {
        if (new File(d, "manifest.json").isFile()) return d;
        if (depth >= 3) return null;
        File[] kids = d.listFiles();
        if (kids == null) return null;
        for (File k : kids) {
            if (k.isDirectory() && !k.getName().equals("__MACOSX")) {
                File r = findManifestDir(k, depth + 1);
                if (r != null) return r;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ bootstrap JS

    private synchronized String shim() {
        if (shimJs == null) {
            try {
                InputStream in = ctx.getAssets().open("shim.js");
                shimJs = readAll(in);
            } catch (IOException e) {
                shimJs = "";
            }
        }
        return shimJs;
    }

    /** Script injected at document start into normal web pages (tabs). */
    synchronized String tabBootstrap() {
        JSONArray reg = new JSONArray();
        for (Info i : list()) {
            if (!i.enabled) continue;
            JSONArray cs = i.manifest.optJSONArray("content_scripts");
            if (cs == null) continue;
            for (int k = 0; k < cs.length(); k++) {
                JSONObject c = cs.optJSONObject(k);
                if (c == null) continue;
                try {
                    JSONObject e = new JSONObject();
                    e.put("x", i.id);
                    e.put("i", k);
                    e.put("m", c.optJSONArray("matches") != null ? c.optJSONArray("matches") : new JSONArray());
                    e.put("e", c.optJSONArray("exclude_matches") != null ? c.optJSONArray("exclude_matches") : new JSONArray());
                    e.put("r", c.optString("run_at", "document_idle"));
                    e.put("f", c.optBoolean("all_frames", false));
                    JSONArray j = c.optJSONArray("js");
                    JSONArray s = c.optJSONArray("css");
                    e.put("j", j != null && j.length() > 0);
                    e.put("c", s != null && s.length() > 0);
                    reg.put(e);
                } catch (JSONException ignored) {
                }
            }
        }
        return "window.__DM_REG=" + reg.toString() + ";\n" + shim();
    }

    /** Script injected at document start into extension popup / background pages. */
    String pageBootstrap(String extId) {
        return "window.__DM_EXT=" + JSONObject.quote(extId) + ";\n" + shim();
    }

    String manifestJson(String id) {
        Info i = find(id);
        return i == null ? "{}" : i.manifest.toString();
    }

    String i18n(String id, String key) {
        Info i = find(id);
        if (i == null) return "";
        return lookupMsg(i.dir, i.manifest, key);
    }

    // ------------------------------------------------------------------ serving files

    WebResourceResponse serveIfExt(Uri u) {
        if (u == null) return null;
        String scheme = u.getScheme();
        if (!"https".equals(scheme) && !"http".equals(scheme)) return null;
        String path = u.getPath();
        if (path == null || !path.startsWith(PREFIX)) return null;
        try {
            return serve(path.substring(PREFIX.length()));
        } catch (Exception e) {
            return resp("text/plain", 500, "Error", "error".getBytes(StandardCharsets.UTF_8));
        }
    }

    private WebResourceResponse serve(String rest) throws Exception {
        int slash = rest.indexOf('/');
        if (slash <= 0) return notFound();
        String id = rest.substring(0, slash);
        String file = rest.substring(slash + 1);
        Info info = find(id);
        if (info == null || !info.enabled) return notFound();

        if (file.startsWith("__cs/") || file.startsWith("__css/")) {
            boolean css = file.startsWith("__css/");
            String num = file.substring(css ? 6 : 5);
            int dot = num.indexOf('.');
            if (dot > 0) num = num.substring(0, dot);
            int idx = Integer.parseInt(num);
            JSONArray cs = info.manifest.optJSONArray("content_scripts");
            JSONObject c = cs == null ? null : cs.optJSONObject(idx);
            if (c == null) return notFound();
            JSONArray files = c.optJSONArray(css ? "css" : "js");
            StringBuilder sb = new StringBuilder();
            if (!css) {
                sb.append("(function(){var __id=").append(JSONObject.quote(id)).append(";")
                        .append("var __api=window.__dmApi&&window.__dmApi(__id);if(!__api)return;")
                        .append("var __oc=Object.getOwnPropertyDescriptor(window,'chrome'),__ob=Object.getOwnPropertyDescriptor(window,'browser');")
                        .append("function __set(k,v){try{Object.defineProperty(window,k,{value:v,configurable:true,writable:true,enumerable:false});}catch(e){}}")
                        .append("function __rs(k,d){try{if(d)Object.defineProperty(window,k,d);else delete window[k];}catch(e){}}")
                        .append("__set('chrome',__api);__set('browser',__api);")
                        .append("try{(function(chrome,browser){\n");
            }
            if (files != null) {
                for (int k = 0; k < files.length(); k++) {
                    File f = safeFile(info.dir, files.optString(k, ""));
                    if (f != null && f.isFile()) {
                        sb.append(readAll(new FileInputStream(f)));
                        sb.append(css ? "\n" : "\n;\n");
                    }
                }
            }
            if (!css) {
                sb.append("\n}).call(window,__api,__api);}catch(e){try{console.error('[extension]',e);}catch(_){}}")
                        .append("finally{__rs('chrome',__oc);__rs('browser',__ob);}})();\n");
            }
            return resp(css ? "text/css" : "application/javascript", 200, "OK", sb.toString().getBytes(StandardCharsets.UTF_8));
        }

        if (file.equals("_bg.html")) {
            JSONObject bg = info.manifest.optJSONObject("background");
            StringBuilder sb = new StringBuilder("<!doctype html><html><head><meta charset=\"utf-8\"></head><body>");
            if (bg != null) {
                JSONArray sc = bg.optJSONArray("scripts");
                if (sc != null) {
                    for (int k = 0; k < sc.length(); k++) {
                        sb.append("<script src=\"").append(escAttr(stripSlash(sc.optString(k)))).append("\"></script>");
                    }
                }
                String sw = bg.optString("service_worker", "");
                if (sw.length() > 0) {
                    sb.append("<script").append("module".equals(bg.optString("type")) ? " type=\"module\"" : "")
                            .append(" src=\"").append(escAttr(stripSlash(sw))).append("\"></script>");
                }
                String page = bg.optString("page", "");
                if (page.length() > 0 && sc == null && sw.length() == 0) {
                    sb.append("<script>location.replace(").append(JSONObject.quote(stripSlash(page))).append(");</script>");
                }
            }
            sb.append("</body></html>");
            return resp("text/html", 200, "OK", sb.toString().getBytes(StandardCharsets.UTF_8));
        }

        File f = safeFile(info.dir, file);
        if (f == null || !f.isFile()) return notFound();
        String mime = mimeOf(f.getName());
        InputStream in = new FileInputStream(f);
        return stream(mime, 200, "OK", in);
    }

    private static String escAttr(String s) {
        return s.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;");
    }

    private static File safeFile(File dir, String rel) {
        try {
            File f = new File(dir, stripSlash(rel));
            String base = dir.getCanonicalPath() + File.separator;
            String c = f.getCanonicalPath();
            if (!c.startsWith(base)) return null;
            return f;
        } catch (IOException e) {
            return null;
        }
    }

    private static String mimeOf(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".js") || n.endsWith(".mjs")) return "application/javascript";
        if (n.endsWith(".json")) return "application/json";
        if (n.endsWith(".html") || n.endsWith(".htm")) return "text/html";
        if (n.endsWith(".css")) return "text/css";
        if (n.endsWith(".svg")) return "image/svg+xml";
        if (n.endsWith(".wasm")) return "application/wasm";
        int dot = n.lastIndexOf('.');
        if (dot >= 0) {
            String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(n.substring(dot + 1));
            if (m != null) return m;
        }
        return "application/octet-stream";
    }

    private static boolean isText(String mime) {
        return mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json") || mime.contains("svg");
    }

    private static Map<String, String> headers() {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        h.put("Cache-Control", "no-cache");
        return h;
    }

    private static WebResourceResponse resp(String mime, int code, String reason, byte[] data) {
        return stream(mime, code, reason, new ByteArrayInputStream(data));
    }

    private static WebResourceResponse stream(String mime, int code, String reason, InputStream in) {
        WebResourceResponse r = new WebResourceResponse(mime, isText(mime) ? "utf-8" : null, in);
        r.setStatusCodeAndReasonPhrase(code, reason);
        r.setResponseHeaders(headers());
        return r;
    }

    private static WebResourceResponse notFound() {
        return resp("text/plain", 404, "Not Found", "not found".getBytes(StandardCharsets.UTF_8));
    }

    // ------------------------------------------------------------------ storage

    private JSONObject store(String id) {
        JSONObject s = stores.get(id);
        if (s == null) {
            s = new JSONObject();
            File f = new File(root, ".store_" + id + ".json");
            if (f.exists()) {
                try {
                    s = new JSONObject(readAll(new FileInputStream(f)));
                } catch (Exception ignored) {
                    s = new JSONObject();
                }
            }
            stores.put(id, s);
        }
        return s;
    }

    private void save(String id) {
        try {
            File f = new File(root, ".store_" + id + ".json");
            FileOutputStream o = new FileOutputStream(f);
            try {
                o.write(store(id).toString().getBytes(StandardCharsets.UTF_8));
            } finally {
                o.close();
            }
        } catch (IOException ignored) {
        }
    }

    synchronized String storageGet(String id, String keysJson) {
        JSONObject s = store(id);
        JSONObject out = new JSONObject();
        try {
            Object k = (keysJson == null || keysJson.equals("null")) ? null : new JSONTokener(keysJson).nextValue();
            if (k == null || k == JSONObject.NULL) {
                Iterator<String> it = s.keys();
                while (it.hasNext()) {
                    String key = it.next();
                    out.put(key, s.get(key));
                }
            } else if (k instanceof String) {
                String ks = (String) k;
                if (s.has(ks)) out.put(ks, s.get(ks));
            } else if (k instanceof JSONArray) {
                JSONArray a = (JSONArray) k;
                for (int i = 0; i < a.length(); i++) {
                    String ks = a.optString(i, "");
                    if (s.has(ks)) out.put(ks, s.get(ks));
                }
            } else if (k instanceof JSONObject) {
                JSONObject d = (JSONObject) k;
                Iterator<String> it = d.keys();
                while (it.hasNext()) {
                    String key = it.next();
                    out.put(key, s.has(key) ? s.get(key) : d.get(key));
                }
            }
        } catch (JSONException ignored) {
        }
        return out.toString();
    }

    /** Returns the "changes" object (empty if nothing changed). */
    synchronized JSONObject storageSet(String id, String objJson) {
        JSONObject changes = new JSONObject();
        try {
            JSONObject in = new JSONObject(objJson);
            JSONObject s = store(id);
            Iterator<String> it = in.keys();
            while (it.hasNext()) {
                String key = it.next();
                Object nv = in.get(key);
                Object ov = s.opt(key);
                JSONObject c = new JSONObject();
                if (ov != null) c.put("oldValue", ov);
                c.put("newValue", nv);
                changes.put(key, c);
                s.put(key, nv);
            }
            save(id);
        } catch (JSONException ignored) {
        }
        return changes;
    }

    synchronized JSONObject storageRemove(String id, String keysJson) {
        JSONObject changes = new JSONObject();
        try {
            Object k = new JSONTokener(keysJson).nextValue();
            List<String> keys = new ArrayList<>();
            if (k instanceof String) keys.add((String) k);
            else if (k instanceof JSONArray) {
                JSONArray a = (JSONArray) k;
                for (int i = 0; i < a.length(); i++) keys.add(a.optString(i, ""));
            }
            JSONObject s = store(id);
            for (String key : keys) {
                if (s.has(key)) {
                    JSONObject c = new JSONObject();
                    c.put("oldValue", s.get(key));
                    changes.put(key, c);
                    s.remove(key);
                }
            }
            save(id);
        } catch (JSONException ignored) {
        }
        return changes;
    }

    synchronized JSONObject storageClear(String id) {
        JSONObject changes = new JSONObject();
        try {
            JSONObject s = store(id);
            Iterator<String> it = s.keys();
            List<String> keys = new ArrayList<>();
            while (it.hasNext()) keys.add(it.next());
            for (String key : keys) {
                JSONObject c = new JSONObject();
                c.put("oldValue", s.get(key));
                changes.put(key, c);
                s.remove(key);
            }
            save(id);
        } catch (JSONException ignored) {
        }
        return changes;
    }

    // ------------------------------------------------------------------ helpers

    private static String readManifestText(File f) throws IOException {
        String t = readAll(new FileInputStream(f));
        if (t.length() > 0 && t.charAt(0) == '﻿') t = t.substring(1);
        return t;
    }

    private String resolveMsg(File dir, JSONObject m, String s) {
        if (s != null && s.startsWith("__MSG_") && s.endsWith("__")) {
            String key = s.substring(6, s.length() - 2);
            String v = lookupMsg(dir, m, key);
            if (v != null && v.length() > 0) return v;
        }
        return s;
    }

    private String lookupMsg(File dir, JSONObject m, String key) {
        String[] langs = {m.optString("default_locale", "en"), "en", "en_US"};
        for (String l : langs) {
            File f = new File(dir, "_locales/" + l + "/messages.json");
            if (!f.isFile()) continue;
            try {
                JSONObject j = new JSONObject(readManifestText(f));
                JSONObject e = j.optJSONObject(key);
                if (e == null) {
                    Iterator<String> it = j.keys();
                    while (it.hasNext()) {
                        String kk = it.next();
                        if (kk.equalsIgnoreCase(key)) {
                            e = j.optJSONObject(kk);
                            break;
                        }
                    }
                }
                if (e != null) return e.optString("message", "");
            } catch (Exception ignored) {
            }
        }
        return "";
    }

    static String readAll(InputStream in) throws IOException {
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[16384];
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            return new String(bo.toByteArray(), StandardCharsets.UTF_8);
        } finally {
            in.close();
        }
    }

    private static void deleteRec(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRec(k);
        }
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    private static void copyRec(File src, File dst) throws IOException {
        if (src.isDirectory()) {
            //noinspection ResultOfMethodCallIgnored
            dst.mkdirs();
            File[] kids = src.listFiles();
            if (kids != null) for (File k : kids) copyRec(k, new File(dst, k.getName()));
        } else {
            FileInputStream in = new FileInputStream(src);
            FileOutputStream out = new FileOutputStream(dst);
            try {
                byte[] b = new byte[16384];
                int n;
                while ((n = in.read(b)) > 0) out.write(b, 0, n);
            } finally {
                in.close();
                out.close();
            }
        }
    }
}
